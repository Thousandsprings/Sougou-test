 
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row justify-content-center">
      <div class="col-md-8">
          <form action="<?php echo e(route('posts.update', $post->id)); ?>" method="POST">
             <?php echo csrf_field(); ?>
             <?php echo method_field('put'); ?>
              <div class="form-group">
                  <label>内容</label>
                  <textarea class="form-control" rows="5" name="body"><?php echo e($post->body); ?></textarea>
              </div>
              <button type="submit" class="btn btn-primary">更新する</button>
          </form>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_original', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Sougou-test/MyEnglishNote/resources/views/posts/edit.blade.php ENDPATH**/ ?>