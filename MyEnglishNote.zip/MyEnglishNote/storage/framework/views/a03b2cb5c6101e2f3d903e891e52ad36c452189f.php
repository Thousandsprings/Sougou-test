 
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
  <div class="row justify-content-center">
      <div class="col-md-8">
            <div class="card text-center">
          <div class="card-header">
              投稿一覧
          </div>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="card-body">
              <p class="card-text">
                内容 : <?php echo e($post->body); ?>

              </p>
              <p class="card-text">投稿者：<?php echo e($post->user->name); ?></p>
              <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-primary">詳細へ</a>
          </div>
          <div class="card-footer text-muted">
              投稿日時 : <?php echo e($post->created_at); ?>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      </div>
      <div class="col-md-2">
        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-primary">
          新規投稿
        </a>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_original', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Sougou-test/MyEnglishNote/resources/views/posts/index.blade.php ENDPATH**/ ?>