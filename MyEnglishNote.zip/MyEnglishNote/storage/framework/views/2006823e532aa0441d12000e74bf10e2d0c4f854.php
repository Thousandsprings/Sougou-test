<?php $__env->startSection('content'); ?>
<div class="container">
      
  <div class="row justify-content-center mt-5">
      <div class="col-md-8">
        <h2>以下の記事にコメントします</h2>
          <div class="card mt-3">
              
              <div class="card-body">
              <p class="card-text">内容：<?php echo e($post->body); ?></p>
              <p>投稿日時：<?php echo e($post->created_at); ?></p>
              
              </div>
          </div>
      </div>
  </div>
  <div class="row justify-content-center mt-5">
    <div class="col-md-8">
        <form action="<?php echo e(route('comments.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
            <div class="form-group">
                <label>コメント</label>
                <textarea class="form-control" 
                placeholder="内容" rows="5" name="body"></textarea>
            </div>
            <button type="submit" class="btn btn-primary mt-3">コメントする</button>
        </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_original', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Sougou-test/MyEnglishNote/resources/views/comments/create.blade.php ENDPATH**/ ?>