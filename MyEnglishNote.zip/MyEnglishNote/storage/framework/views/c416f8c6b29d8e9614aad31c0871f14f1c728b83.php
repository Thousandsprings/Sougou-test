 

<?php $__env->startSection('content'); ?>


<div class="container mt-5">
  <div class="row justify-content-center">
      <div class="col-md-8">
          <form action="<?php echo e(route('posts.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
              
            
              <div class="form-group">
                  <label>内容</label>
                  <textarea class="form-control" placeholder="内容" rows="5" name="body">
                  </textarea>
              </div>
              <button type="submit" class="btn btn-primary" >作成</button>
          </form>
      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app_original', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Sougou-test/MyEnglishNote/resources/views/posts/create.blade.php ENDPATH**/ ?>